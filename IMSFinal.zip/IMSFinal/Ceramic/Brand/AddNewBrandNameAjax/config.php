<?php
    $servername = 'localhost';
    $username = 'root';
    $pwd = '';
    $dbname = 'imsfinal';

    $conn = mysqli_connect($servername, $username, $pwd, $dbname);
?>