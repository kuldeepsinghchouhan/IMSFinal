<?php
			
			$conn =mysqli_connect('localhost', 'root', '','imsfinal');

			if (!$conn) {
				echo hello;
	    		echo die("Connection failed: " . mysqli_connect_error());
				}
			else{
				
			}

?>